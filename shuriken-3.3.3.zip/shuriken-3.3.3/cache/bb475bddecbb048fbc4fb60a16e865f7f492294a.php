<?php $__env->startSection('head'); ?>
<title><?php echo e(site_name()); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bg'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(isset($_GET['img'])): ?>
	<div class="row">
		<div class="col-md-12 text-center">
			<p><a href="<?php echo e($_GET['img']); ?>" class="btn btn-outline-primary" download="image">Download Image</a></p>
			<p><img src="<?php echo e($_GET['img']); ?>" alt="" class="img-fluid"></p>

		</div>
	</div>
	<div class="mt-3"></div>
	<?php endif; ?>

	<?php $__currentLoopData = collect(keywords())->shuffle()->take(16)->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row mt-3">
			<?php $__currentLoopData = $chunked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-3">
					<p class="text-center"><?php echo e($keyword); ?></p>
					<a href="<?php echo e(image_url($keyword)); ?>">
						<img src="<?php echo e(image_url($keyword, true)); ?>" alt="" class="img-fluid" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';">
					</a>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>